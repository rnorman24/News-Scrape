module.exports = {
  Headline: require("./Headline"),
  Note: require("./Note")
};
